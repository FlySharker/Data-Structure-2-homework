#include<iostream>
#include<vector>
using namespace std;


// ����ṹ��
struct Node {
    int key;
    int value;
    Node* next;
    Node(int k, int v) : key(k), value(v), next(nullptr) {}
};

// ����HashTable��
class HashTable {
private:
    vector<Node*> table;
    int size;
    int capacity;
    int hash(int key) {
        return key % capacity; // ʹ�ó���������Ϊ��ϣ����
    }
public:
    HashTable(int capacity) : size(0), capacity(capacity) {
        table.resize(capacity, nullptr);
    }

    // ���뺯�� 
    void insert(int key, int value) {
        int index = hash(key);
        Node* node = new Node(key, value);
        if (table[index] == nullptr) {
            table[index] = node;
        } else {
            Node* curr = table[index];
            while (curr->next != nullptr) {
                curr = curr->next;
            }
            curr->next = node;
        }
        size++;
    }

    // ���Һ��� 
    int search(int key) {
        int index = hash(key);
        Node* curr = table[index];
        while (curr != nullptr) {
            if (curr->key == key) {
                return curr->value;
            }
            curr = curr->next;
        }
        return -1; 
    }

    // ɾ������ 
    void remove(int key) {
        int index = hash(key);
        Node* curr = table[index];
        Node* prev = nullptr;
        while (curr != nullptr) {
            if (curr->key == key) {
                if (prev == nullptr) {
                    table[index] = curr->next;
                } else {
                    prev->next = curr->next;
                }
                delete curr;
                size--;
                return;
            }
            prev = curr;
            curr = curr->next;
        }
    }
    
    //չʾ��ϣ��
	void display() {
	for (int i = 0; i < capacity; i++) {
	cout << "[" << i << "]: ";
	Node* curr = table[i];
	while (curr != nullptr) {
	cout << "(" << curr->key << ", " << curr->value << ")";
	if (curr->next != nullptr) {
	cout << " -> ";
	}
	curr = curr->next;
	}
	cout << endl;
	}
	}
};

int main() {
	int choice=-1,key,value,cap; 
	HashTable ht(10);
	//HashTable ht(7);
    ht.insert(1, 10);
    ht.insert(11, 20);
    ht.insert(21, 30);
    ht.insert(40,19);
	ht.insert(30,39); 
	ht.insert(64,23);
	ht.insert(44,33); 
	ht.insert(57,66);
	ht.insert(38,47);
	ht.insert(69,96);
	ht.insert(5,66);
	while (1) {
        cout << "1. չʾ��ϣ��" << endl;
        cout << "2. ���뺯������" << endl;
        cout << "3. ���Һ�������" << endl;
        cout << "4. ɾ����������" << endl;
        cout << "5. �����ݻ���������" << endl;
        cout << "0. �˳�����" << endl;
        cout << "��ѡ��: ";
        cin >> choice;
        switch (choice) {
        case 1:
		    ht.display();
            break;
        case 2:
        	cout<<"��������Ҫ����Ĺؼ��ֺ�ֵ:"<<endl;
        	cin>>key>>value;
        	ht.insert(key,value);
            break;
        case 3:
        	cout<<"��������Ҫ���ҵĹؼ��֣�"<<endl;
        	cin>>key;
            cout << "�ùؼ��ֶ�Ӧ��ֵΪ��" << ht.search(key) << endl;
            break;
        case 4:
            cout<<"��������Ҫɾ���Ĺؼ���:"<<endl;
            cin>>key;
            ht.remove(key); 
			break;
        default:
            return 0;
        }
    }
    return 0;
}

/*  ht.insert(11, 10);
    ht.insert(23, 20);
    ht.insert(24, 30);
    ht.insert(48,19);
    ht.insert(118,39);
    ht.insert(13,23);
    ht.insert(56,33);
    ht.insert(102,66);
    ht.insert(43,47);
    ht.insert(90,96);
    ht.insert(78,66);
*/

/*  ht.insert(22, 10);
    ht.insert(41, 20);
    ht.insert(53, 30);
    ht.insert(46,19);
    ht.insert(30,39);
    ht.insert(13,23);
    ht.insert(1,33);
    ht.insert(69,66);
    ht.insert(49,47);
    ht.insert(93,96);
    ht.insert(76,66);
*/
