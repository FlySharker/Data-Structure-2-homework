#include <bits/stdc++.h>
using namespace std;
#define TABLE_SIZE 23

// �ڵ㶨�� 
struct HashNode
{
    int key;
    bool deleted;
};

HashNode hashTable[TABLE_SIZE];

// �����෨��ϣ���� 
int hashFunction(int key)
{
    return key % TABLE_SIZE;
}

// ��ʼ�� 
void init(HashNode h[])
{
    for (int i = 0; i < TABLE_SIZE; i++)
    {
        h[i].key = 0;
        h[i].deleted = false;
    }
}

// ����̽�⺯�� 
int quadraticProbing(int hashIndex, int count, int temp)
{
    if (count % 2 == 0)
        temp = (hashIndex + (int)pow((1 + count / 2), 2) + TABLE_SIZE) % TABLE_SIZE; /*����̽��*/
    else
        temp = (hashIndex - (int)pow((1 + count / 2), 2) + TABLE_SIZE) % TABLE_SIZE; /*����̽��*/
    return temp;
}

// ���뺯�� 
void insert(int key)
{
    int hashIndex = hashFunction(key);
    int temp = hashIndex;
    int count = 0;
    while (hashTable[temp].key != 0 && hashTable[temp].deleted != true)
    {
        temp = quadraticProbing(hashIndex, count, temp);
        count++;
    }
    hashTable[temp].key = key;
    hashTable[temp].deleted = false;
}

// ���Һ��� 
int search(int key)
{
    int hashIndex = hashFunction(key);
    int count = 0;
    int temp = hashIndex;
    while (hashTable[temp].key != 0)
    {
        if (hashTable[temp].key == key && hashTable[temp].deleted != true)
        {
            return temp;
        }
        temp = quadraticProbing(hashIndex, count, temp);
        count++;
    }
    return -1;
}

// ɾ������ 
void deleteKey(int key)
{
    int hashIndex = hashFunction(key);
    int count = 0;
    int temp = hashIndex;
    while (hashTable[temp].key != 0)
    {
        if (hashTable[temp].key == key && hashTable[temp].deleted != true)
        {
            hashTable[temp].deleted = true;
            return;
        }
        temp = quadraticProbing(hashIndex, count, temp);
        count++;
    }
}

//չʾ��ϣ�� 
void showHashTable()
{
for (int i = 0; i < TABLE_SIZE; i++)
{
if (hashTable[i].deleted == true)
cout << "[" << i << "]: deleted" << endl;
else if (hashTable[i].key == 0)
cout << "[" << i << "]: empty" << endl;
else
cout << "[" << i << "]: " << hashTable[i].key << endl;
}
}

int main()
{
	int key,choice;
    init(hashTable);
    int a[] = {4, 17, 23, 45, 19, 26, 14, 40};
    int n = sizeof(a) / sizeof(a[0]);
    for (int i = 0; i < n; i++)
    {
        insert(a[i]);
    }
    while (1) 
	{
        cout << "1. չʾ��ϣ��" << endl;
        cout << "2. ���뺯������" << endl;
        cout << "3. ���Һ�������" << endl;
        cout << "4. ɾ����������" << endl;
        cout << "0. �˳�����" << endl;
        cout << "��ѡ��: ";
        cin >> choice;
        switch (choice) {
        case 1:
		    showHashTable();
            break;
        case 2:
        	cout<<"��������Ҫ����Ĺؼ���:"<<endl;
        	cin>>key;
        	insert(key);
            break;
        case 3:
        	cout<<"��������Ҫ���ҵĹؼ��֣�"<<endl;
        	cin>>key;
            cout << "�ùؼ��ֵ�λ��Ϊ��" << search(key) << endl;
            break;
        case 4:
            cout<<"��������Ҫɾ���Ĺؼ���:"<<endl;
            cin>>key;
            deleteKey(key);
			break;
        default:
            return 0;
        }
    }
//    deleteKey(a[6]);
//    for (int i = 0; i < n; i++)
//    {
//        printf("%d\n", search(a[i]));
//    }
//    cout << endl;
//    init(hashTable);
//    int b[] = {22,41,53,46,30,13,1,69};
//    int m = sizeof(b) / sizeof(b[0]);
//    for (int i = 0; i < m; i++)
//    {
//        insert(b[i]);
//    }
//    deleteKey(b[6]);
//    for (int i = 0; i < m; i++)
//    {
//        printf("%d\n", search(b[i]));
//    }
//    cout << endl;
//    init(hashTable);
//    int c[] = {11,23,24,48,118,13,56,102};
//    int y = sizeof(c) / sizeof(c[0]);
//    for (int i = 0; i < y; i++)
//    {
//        insert(c[i]);
//    }
//    deleteKey(c[6]);
//    for (int i = 0; i < y; i++)
//    {
//        printf("%d\n", search(c[i]));
//    }
    return 0;
}
